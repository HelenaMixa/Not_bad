from django.db import models


class Club(models.Model):
    name_club = models.CharField(max_length=50)
    coach = models.CharField(max_length=50)
    town = models.CharField(max_length=20)
    
    def __str__(self):
        return self.name_club

class Person(models.Model):
    name = models.CharField(max_length=50)
    surname= models.CharField(max_length=50)
    birth_date=models.DateField(null=True,blank=True)
    coach= models.CharField(max_length=20)
    
    def __str__(self):
        return '{}{}{}'.format(self.name,self.coach, self.surname)

    #def __str__(self):
        #return self.name

class Member(models.Model):
    Pay = models.IntegerField()       
    People = models.ForeignKey(Person,on_delete =models.CASCADE)

    def __str__(self):
        return self.People









