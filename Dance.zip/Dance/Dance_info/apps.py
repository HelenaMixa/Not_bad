from django.apps import AppConfig


class DanceInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Dance_info'
